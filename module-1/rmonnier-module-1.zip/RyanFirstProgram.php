<!-- 
Ryan Monnier
CSD 440
Module 1
26-Oct-2025
-->


<!DOCTYPE html>
<html>
<body>
 
<?php
echo "My first PHP script!";
?>

</body>
</html>

<!-- Script taken from  https://www.w3schools.com/php/ -->
